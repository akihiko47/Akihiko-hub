import pygame

pygame.init()

"""screen set"""
W, H = 800, 800
screen = pygame.display.set_mode((W, H))

"""colors"""
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (223, 7, 114)
RED_DARKER = (180, 0, 70)
PINK = (245, 0, 224)
BLUE = (25, 255, 230)
BLUE_DARKER = (5, 235, 210)
DARK_BLUE = (25, 136, 165)
DARK_BLUE_ACT = (0, 111, 140)
DEEP_BLUE = (53, 42, 85)
YELLOW = (255, 208, 128)
ORANGE = (255, 158, 125)
