import numpy as np
import pygame
from random import randint, uniform
import asyncio

pygame.init()


def func(x, y, n, balls):
    try:
        return round(sum([balls[i][2]**2 / ((x - balls[i][0])**2 + (y - balls[i][1])**2) for i in range(n)]), 2)
    except ZeroDivisionError:
        return round(sum([balls[i][2] ** 2 for i in range(n)]), 2)


async def main():
    # SETTINGS
    matrix_size = 100
    cube_size = 10
    b_counter = 5
    b_sizes = [5, 20]  # to - from
    b_speeds = [0, 1]

    # colors
    BLACK = (37, 42, 52)
    RED = (255, 46, 99)
    BLUE = (8, 217, 214)

    # pygame part
    display_width = matrix_size * cube_size
    display_height = matrix_size * cube_size

    display = pygame.display.set_mode((display_width, display_height))
    pygame.display.set_caption("BLOBS")

    clock = pygame.time.Clock()

    # creating balls
    balls = []
    for i in range(b_counter):
        balls.append([randint(b_sizes[1], matrix_size-b_sizes[1]), randint(b_sizes[1], matrix_size-b_sizes[1]),
                      randint(b_sizes[0], b_sizes[1]),
                      uniform(b_speeds[0], b_speeds[1]), uniform(b_speeds[0], b_speeds[1])])


    in_game = True
    points = np.empty((matrix_size, matrix_size))

    while in_game:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                in_game = False
                pygame.quit()
                quit()

        for y in range(matrix_size):
            for x in range(matrix_size):
                points[y][x] = func(x, y, b_counter, balls)
                color = BLACK if points[y][x] < 1 else RED
                pygame.draw.rect(display, color, (x*cube_size, y*cube_size, cube_size, cube_size))

        for ball in balls:
            ball[0] += ball[3]
            ball[1] += ball[4]

            if ball[0] - ball[2] < 0:
                ball[0] = ball[2]
                ball[3] = -ball[3]
            if ball[0] + ball[2] > matrix_size:
                ball[0] = matrix_size - ball[2]
                ball[3] = -ball[3]
            if ball[1] - ball[2] < 0:
                ball[1] = ball[2]
                ball[4] = -ball[4]
            if ball[1] + ball[2] > matrix_size:
                ball[1] = matrix_size - ball[2]
                ball[4] = -ball[4]

        pygame.display.update()
        await asyncio.sleep(0)
        clock.tick(100)

if __name__ == '__main__':
    asyncio.run(main())
