import pygame
from Ball_class import Ball
from itertools import combinations
import numpy as np
from random import randint
import math
import asyncio

pygame.init()


def handle_collisions(balls):
    pairs = combinations(range(len(balls)), 2)
    for i, j in pairs:
        if check_overlap(balls[i], balls[j]):
            change_velocities(balls[i], balls[j])


def change_velocities(p1, p2):
    p1.r = p1.r
    m1, m2 = p1.radius ** 2, p2.radius ** 2
    M = m1 + m2
    r1, r2 = p1.r, p2.r
    d = np.linalg.norm(r1 - r2) ** 2
    v1, v2 = p1.v, p2.v
    u1 = v1 - 2 * m2 / M * np.dot(v1 - v2, r1 - r2) / d * (r1 - r2)
    u2 = v2 - 2 * m1 / M * np.dot(v2 - v1, r2 - r1) / d * (r2 - r1)
    p1.v = u1
    p2.v = u2


def check_overlap(p1, p2):
    dist = math.hypot(p1.r[0]-p2.r[0], p1.r[1]-p2.r[1])
    return dist <= p1.radius + p2.radius


async def main():
    # display part
    display_width = 1000
    display_height = 1000

    display = pygame.display.set_mode((display_width, display_height))
    pygame.display.set_caption("My Balls!")

    # clock part
    clock = pygame.time.Clock()

    # colors
    BLACK = (31, 31, 41)
    GREY = (65, 58, 66)
    ORANGE = (209, 124, 124)
    YELLOW = (246, 198, 168)

    # mouse start speed
    mouse_pos_prev = [0, 0]

    balls = []

    # settings
    friction_cf = 1
    max_rad = 150

    # main game loop
    radius = 60
    size_counter = 0

    while True:
        # mouse velocity calculations
        mouse_pos = pygame.mouse.get_pos()
        v_mouse = [mouse_pos[0] - mouse_pos_prev[0], mouse_pos[1] - mouse_pos_prev[1]]
        mouse_pos_prev = mouse_pos

        for event in pygame.event.get():
            # exit action
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            # keys
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    quit()

            # mouse actions
            if event.type == pygame.MOUSEBUTTONUP:
                for ball in balls:
                    if check_overlap(ball, Ball(mouse_pos[0], mouse_pos[1], 0, 0, size_counter//2 + 30)):
                        break
                else:
                    balls.append(Ball(mouse_pos[0], mouse_pos[1], v_mouse[0]*0.3, v_mouse[1]*0.3, size_counter//2 + 30))

        # fill display
        display.fill(GREY)

        # radius maker
        mouse = pygame.mouse.get_pressed(3)
        if mouse[0]:
            size_counter += 1
        else:
            size_counter = 0

        # collisions
        handle_collisions(balls)

        # update and draw balls
        for ball in balls:
            ball.update(display_width, display_height, friction_cf)
            ball.draw(display, YELLOW)

        pygame.display.update()
        await asyncio.sleep(0)
        clock.tick(60)

if __name__ == '__main__':
    asyncio.run(main())