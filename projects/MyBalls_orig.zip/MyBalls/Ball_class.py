import numpy as np
import pygame.draw


class Ball:
    def __init__(self, x, y, vx, vy, radius):
        self.r = np.array((x, y))
        self.v = np.array((vx, vy))
        self.radius = radius

    def add_friction(self, fr):
        self.v[0] = self.v[0] * fr
        self.v[1] = self.v[1] * fr

    def make_movement(self):
        self.r[0] += round(self.v[0])
        self.r[1] += round(self.v[1])

    def check_walls(self, dw, dh):
        if self.r[0] - self.radius < 0:
            self.r[0] = self.radius
            self.v[0] = -self.v[0]
        if self.r[0] + self.radius > dw:
            self.r[0] = dw - self.radius
            self.v[0] = -self.v[0]
        if self.r[1] - self.radius < 0:
            self.r[1] = self.radius
            self.v[1] = -self.v[1]
        if self.r[1] + self.radius > dh:
            self.r[1] = dh - self.radius
            self.v[1] = -self.v[1]

    def update(self, display_w, display_h, friction):
        self.make_movement()
        self.check_walls(display_w, display_h)
        self.add_friction(friction)

    def draw(self, display, color, fr_w=0):
        pygame.draw.circle(display, color, self.r, self.radius, fr_w)
