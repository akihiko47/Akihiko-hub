from mutagen.mp3 import MP3
import pygame
import random
import os
import asyncio

pygame.init()


def get_random_sound():
    n = random.random()
    if n <= 0.05:
        list = os.listdir('sounds/hard/')
        number_files = len(list)
        sound_num = random.randint(1, number_files)
        sound_path = f"sounds/hard/{sound_num}.mp3"
        sound = pygame.mixer.Sound(sound_path)
        sound_len = MP3(sound_path).info.length
        return sound, sound_len, 2, sound_path
    elif 0.05 < n < 0.4:
        list = os.listdir('sounds/medium/')
        number_files = len(list)
        sound_num = random.randint(1, number_files)
        sound_path = f"sounds/medium/{sound_num}.mp3"
        sound = pygame.mixer.Sound(sound_path)
        sound_len = MP3(sound_path).info.length
        return sound, sound_len, 1, sound_path
    elif n >= 0.4:
        list = os.listdir('sounds/easy/')
        number_files = len(list)
        sound_num = random.randint(1, number_files)
        sound_path = f"sounds/easy/{sound_num}.mp3"
        sound = pygame.mixer.Sound(sound_path)
        sound_len = MP3(sound_path).info.length
        return sound, sound_len, 0, sound_path


async def main():
    # display part
    infoObject = pygame.display.Info()
    display = pygame.display.set_mode((infoObject.current_w, infoObject.current_h), pygame.RESIZABLE, pygame.FULLSCREEN)
    pygame.display.set_caption("RUSSIAN SWEARING")

    display_width, display_height = display.get_size()

    # intro part
    sound = pygame.mixer.Sound('video/sound.mp3')
    pygame.mixer.Sound.play(sound)

    # collection part
    len_e = len(os.listdir('sounds/easy/'))
    len_m = len(os.listdir('sounds/medium/'))
    len_h = len(os.listdir('sounds/hard/'))
    used_e = []
    used_m = []
    used_h = []

    # icon part
    try:
        icon = pygame.image.load("images/icon.ico")
        pygame.display.set_icon(icon)
    except:
        print("Не получилось загрузить иконку игры!")

    # fps part
    clock = pygame.time.Clock()
    FPS = 15

    # images part
    main_face_img_org_0 = pygame.image.load('images/main_face_0.png')
    main_face_img_opened_org_0 = pygame.image.load('images/main_face_open_0.png')
    main_face_img_org_1 = pygame.image.load('images/main_face_1.png')
    main_face_img_opened_org_1 = pygame.image.load('images/main_face_open_1.png')
    main_face_img_org_2 = pygame.image.load('images/main_face_2.png')
    main_face_img_opened_org_2 = pygame.image.load('images/main_face_open_2.png')
    main_face_img_org_3 = pygame.image.load('images/main_face_3.png')
    main_face_img_opened_org_3 = pygame.image.load('images/main_face_open_3.png')

    background_img_org = pygame.image.load('images/background.jpg')
    background_img_org2 = pygame.image.load('images/background2.jpg')
    hell_background_img_org = pygame.image.load('images/hell_background.jpg')
    hell_background_img_org2 = pygame.image.load('images/hell_background2.jpg')

    glasses_img_org = pygame.image.load('images/glasses.png')

    blur_e_img_org = pygame.image.load('images/blur_e.png')
    blur_m_img_org = pygame.image.load('images/blur_m.png')
    blur_h_img_org = pygame.image.load('images/blur_h.png')

    # music part
    pygame.mixer.music.load('sounds/music2.mp3')
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(-1)  # If the loops is -1 then the music will repeat indefinitely.

    # start of main game loop
    in_game = True
    talking = False
    started = False
    game_completed = False
    pig_level = 0
    shaking_coef = 0
    level = 0
    counter = 0


    while in_game:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                started = True
                talking = True
                sound_path = f"sounds/quit.mp3"
                sound = pygame.mixer.Sound(sound_path)
                sound_len = MP3(sound_path).info.length
                pygame.mixer.Sound.play(sound)

                shaking_coef = 0.05
                level = 2

                counter = int(sound_len * FPS)

            if event.type == pygame.MOUSEBUTTONUP and not talking:
                started = True
                talking = True
                sound, sound_len, level, path = get_random_sound()

                if path not in used_h and path not in used_m and path not in used_e:
                    if level == 0:
                        used_e.append(path)
                    elif level == 1:
                        used_m.append(path)
                    elif level == 2:
                        used_h.append(path)

                if level == 0:
                    shaking_coef = 0.001
                elif level == 1:
                    shaking_coef = 0.005
                elif level == 2:
                    shaking_coef = 0.05

                pygame.mixer.Sound.play(sound)
                if not game_completed:
                    counter = int(sound_len * FPS)
                else:
                    counter = 5

        # cheat code
        keys = pygame.key.get_pressed()
        if keys[pygame.K_n] and keys[pygame.K_i] and keys[pygame.K_g] and keys[pygame.K_e] and keys[pygame.K_r]:
            game_completed = True

        # pig level check
        pig_level = 0
        if len(used_h) > 0:
            pig_level += 1
        if len(used_e) == len_e or len(used_m) == len_m or len(used_h) == len_h:
            pig_level += 1
        if len(used_e) == len_e and len(used_m) == len_m and len(used_h) == len_h:
            pig_level += 1

        # cooldown part
        if counter > 0:
            counter -= 1
        if counter == 0:
            talking = False
            shaking_coef = 0

        # resizing images
        display_width, display_height = display.get_width(), display.get_height()

        # check game end
        if len(used_e) == len_e and len(used_m) == len_m and len(used_h) == len_h and not game_completed:
            game_completed = True

        # get background
        if game_completed:
            background_img = pygame.transform.scale(background_img_org, (display_width, display_height))
            hell_background_img = pygame.transform.scale(hell_background_img_org, (display_width, display_height))
        else:
            background_img = pygame.transform.scale(background_img_org2, (display_width, display_height))
            hell_background_img = pygame.transform.scale(hell_background_img_org2, (display_width, display_height))

        # get face img
        face_img = main_face_img_org_0
        if talking:
            if pig_level == 0:
                face_img = pygame.transform.scale(main_face_img_opened_org_0, (display_width * 0.8, display_height * 0.8))
            elif pig_level == 1:
                face_img = pygame.transform.scale(main_face_img_opened_org_1, (display_width * 0.8, display_height * 0.8))
            elif pig_level == 2:
                face_img = pygame.transform.scale(main_face_img_opened_org_2, (display_width * 0.8, display_height * 0.8))
            elif pig_level == 3:
                face_img = pygame.transform.scale(main_face_img_opened_org_3, (display_width * 0.8, display_height * 0.8))
        else:
            if pig_level == 0:
                face_img = pygame.transform.scale(main_face_img_org_0, (display_width * 0.8, display_height * 0.8))
            elif pig_level == 1:
                face_img = pygame.transform.scale(main_face_img_org_1, (display_width * 0.8, display_height * 0.8))
            elif pig_level == 2:
                face_img = pygame.transform.scale(main_face_img_org_2, (display_width * 0.8, display_height * 0.8))
            elif pig_level == 3:
                face_img = pygame.transform.scale(main_face_img_org_3, (display_width * 0.8, display_height * 0.8))

        # draw background
        if talking and level == 2:
            display.blit(hell_background_img, (0, 0))
        else:
            display.blit(background_img, (0, 0))

        # draw face
        display.blit(face_img, (
            display_width * 0.1 + random.uniform(-shaking_coef * display_width,
                                                 shaking_coef * display_width),
            display_height * 0.1 + random.uniform(-shaking_coef * display_height,
                                                  shaking_coef * display_height)))

        # draw blur
        if talking:
            if level == 0:
                blur_img = pygame.transform.scale(blur_e_img_org, (display_width, display_height))
            elif level == 1:
                blur_img = pygame.transform.scale(blur_m_img_org, (display_width, display_height))
            else:
                blur_img = pygame.transform.scale(blur_h_img_org, (display_width, display_height))

            display.blit(blur_img, (0, 0))

        # draw start screen and phrases counters
        if not started:
            glasses_img = pygame.transform.scale(glasses_img_org, (display_width * 0.5, display_height * 0.2))

            # font part
            font = pygame.font.SysFont('silkscreen.ttf', int(display_width * 0.1))

            display.blit(glasses_img, (display_width * 0.25, display_height * 0.25))
            text1 = font.render("СИМУЛЯТОР", False, (255, 255, 255))
            text2 = font.render("РУССКОГО", False, (255, 255, 255))
            text3 = font.render("МАТА", False, (255, 255, 255))

            display.blit(text1, (display_width * 0.28, display_height * 0.3))
            display.blit(text2, (display_width * 0.3, display_height * 0.45))
            display.blit(text3, (display_width * 0.41, display_height * 0.6))
        else:
            pygame.mixer.music.set_volume(0.1)

            font = pygame.font.Font('images/EvilEmpire-4BBVK.ttf', int(display_width * 0.05))

            e_text = font.render(f"{len(used_e)}/{len_e}", False, (18, 133, 35))
            display.blit(e_text, (display_width * 0.85, display_height * 0.57))

            m_text = font.render(f"{len(used_m)}/{len_m}", False, (44, 44, 201))
            display.blit(m_text, (display_width * 0.85, display_height * 0.7))

            h_text = font.render(f"{len(used_h)}/{len_h}", False, (99, 67, 141))
            display.blit(h_text, (display_width * 0.85, display_height * 0.83))

        pygame.display.update()
        await asyncio.sleep(0)
        clock.tick(FPS)

if __name__ == "__main__":
    asyncio.run(main())
